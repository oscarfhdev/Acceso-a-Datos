public class AlumnoNotFound extends RuntimeException {
    public AlumnoNotFound(String message) {
        super(message);
    }
}
